# 📈 08 · Budget, Monetization & Launch Marketing

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Budget planning envelope
**₹12–30 lakh** for the narrowed MVP is a working planning envelope to use while obtaining quotes.
| **Component** | **Planning estimate** |
| --- | --- |
| Engineering, design, QA, specialist reviews and launch preparation | Approximately ₹10–25 lakh |
| Contingency | 20% |
| Total envelope | Approximately ₹12–30 lakh |
> **\[Unverified\] Estimates, not market quotations.** Excludes your salary, sustained marketing and potentially material bank-data partnership or verification costs.
Request milestone-based quotes against the narrow scope. Require source-code access and working demonstrations throughout.
## Recurring costs
Hosting + storage + OCR/AI + transaction-data access + support + monitoring + billing fees + maintenance.
Measure cost for both free and paying users. Avoid unlimited scans or lifetime automation promises before measuring provider costs and ongoing usage.
## Illustrative contribution model
**Assumptions, not observed business results:**
| **Input** | **Illustrative value** |
| --- | --- |
| Net subscription receipts per paying user/month | ₹120 |
| Variable servicing cost per paying user/month | ₹40 |
| Contribution per paying user/month | ₹80 |
| Acquisition cost per paying user | ₹400 |
| Simple contribution payback | Five months: ₹400 ÷ ₹80 |
This excludes fixed costs and does not account for churn. It shows the quantities to measure, not a forecast.
## Monetization tests
- Test concrete subscription offers, rather than hypothetical willingness.
- Describe capture differences and usage limits clearly.
- Measure free-user costs as well as paid-user costs.
- Keep export and access to existing records available after cancellation, as proposed in the PDF.
## Early marketing
- Recruit through communities matching the initial segment, with permission.
- Publish short demonstrations using synthetic financial data.
- Show the correction experience and supported capture methods.
- Explain collection, uploading, retention and revocation precisely.
- Test a small number of positioning messages.
- Use separate Android/iOS descriptions where capture differs.
- Delay substantial paid acquisition until users return across monthly cycles.
## Product and business metrics
| **Metric** | **Why it matters** |
| --- | --- |
| Time to first useful spending report | Whether onboarding delivers value |
| Successful import/connection rate | Whether capture works |
| Corrections per 100 transactions | Whether automation saves effort |
| Return for the next monthly report | Whether value persists |
| Reports users describe as trustworthy | Whether results support decisions |
| Paid conversion and cancellation reasons | Whether value supports a business |
| Support time per active user | Whether operations can scale |
Daily opens are a weak primary success measure for an app intended to reduce tracking effort.
## Investment decision
> Can the app capture enough data, classify it correctly and require little enough correction that users continue trusting the result?
Establish this before funding the broader financial command centre.
