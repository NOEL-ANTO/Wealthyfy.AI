# 🏗️ 05 · Technical Architecture & Data Model

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Architectural recommendation
Retain React Native and TypeScript from the brief. Favour PostgreSQL over MongoDB for the core financial records because of relationships and transactional consistency—not because MongoDB cannot support the product.
| **Layer** | **Recommendation** |
| --- | --- |
| Android/iOS app | React Native + TypeScript + Expo development builds |
| Offline storage | SQLite with a supported encryption and key-management approach |
| Backend | One TypeScript application, rather than multiple microservices |
| Core database | Managed PostgreSQL |
| Receipt storage | Private object storage with short-lived access links |
| Processing | Background jobs for imports, OCR and recurring detection |
| Authentication | Managed authentication with server-side authorization |
| Notifications | Local reminders where suitable; remote push for server events |
| Operations | Automated builds, error monitoring, backups and feature flags |
## Native builds early
Expo Go has a fixed native library set. Native integrations beyond that set require development builds. Test SMS capture and other platform features in actual native builds early.
## Separate source evidence from financial records
| **Record type** | **Purpose** |
| --- | --- |
| Source records | Imported evidence and external identifiers |
| Transactions | Normalized financial events |
| Category allocations | Category assignments and optional splits |
| Attachments | Receipts and statements |
| Matches | Relationships between supporting records |
| Recurring candidates | Suggestions awaiting confirmation |
| Corrections | User changes that survive re-imports |
| Sync operations | Pending changes and deletion markers |
| Consent records | What access was authorized and when |
## Money and repeat-safe processing
- Store exact money units: for INR, integer paise rather than floating-point numbers.
- Use stable identifiers.
- Make import and sync retries repeat-safe so they do not create duplicates.
- Specify conflict handling before supporting multiple devices.
- Keep provenance and user corrections available for review.
## AI boundaries
Start with deterministic parsers and merchant rules. Use AI selectively for ambiguous text and OCR assistance.
**Calculate totals and comparisons in application code.**
**\[Inference\]** If an assistant is added later, treat receipt text and transaction descriptions as untrusted input. Restrict its tools and validate outputs. These controls are intended to reduce unsafe behavior, not guarantee its absence.
## Build sequence
1. Transaction model and accounting rules.
2. One capture/import route.
3. Categorization and corrections.
4. Reports with source/freshness indicators.
5. Offline queue and sync.
6. Confirmed recurring-payment candidates.
7. Additional integrations only after validation.
## Sources
- [Expo: Development builds FAQ](https://docs.expo.dev/develop/development-builds/faq/)
