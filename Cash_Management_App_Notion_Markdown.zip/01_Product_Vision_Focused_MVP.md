# 🎯 01 · Product Vision & Focused MVP

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Recommendation
Build a **trustworthy expense tracker that captures transactions with minimal effort, explains where money went, and clearly shows what information is missing**. Add proactive bills and subscription intelligence after this foundation works.
The biggest risk is obtaining sufficiently complete, accurate transaction data on both Android and iOS. Attractive dashboards and AI insights depend on that foundation.
## Two product promises
The immediate request focuses on: “Help me understand where my expenses are going, without making me record everything.”
The PDF focuses on: “Find the money requiring my attention.”
| **Promise** | **Capabilities that must work** |
| --- | --- |
| Explain my spending | Capture, categorization, transfers, refunds, reconciliation and completeness |
| Tell me what needs attention | Due dates, recurring payments, payment status and useful alerts |
| Recover wasted or owed money | Reliable subscription evidence, IOUs and follow-up workflows |
| Manage business finances | Invoices, tax treatment, customers, mileage and business reporting |
**Recommendation:** make spending awareness the first promise, with a small recurring-payment feature as the first extension.
> The PDF’s V1 postpones most transaction automation to V2. A manual tracker with OCR would not validate the proposed automatic-tracking experience. Statement imports can validate categorization and insights, but cannot by themselves validate continuous “give permission and forget about it” capture.
## Production MVP
| **Include** | **Purpose** |
| --- | --- |
| One validated primary capture route | Tests the automation proposition |
| Manual entry and cash support | Handles unavoidable gaps |
| Supported statement imports | Provides history and a cross-platform fallback |
| Basic receipts: merchant, date, amount and attachment | Captures missing expenses without full item-level complexity |
| Expenses, income, transfers and refunds | Makes reports financially coherent |
| Categories and remembered user corrections | Reduces repeated effort |
| Review inbox and duplicate handling | Builds trust |
| Monthly, category and merchant summaries | Answers the core spending question |
| Source and freshness indicators | Exposes incomplete data |
| Small confirmed recurring-payment list | Tests the proactive extension |
| Offline entry, backup/sync status, CSV export and deletion | Supports dependable everyday use |
## Defer until the core is validated
- Business mode, invoices, mileage and tax reports.
- Automatic subscription usage monitoring.
- Family collaboration and shared wallets.
- Full receipt line-item classification.
- Broad Gmail/Outlook access.
- A general financial chatbot.
- Savings recommendations and forecasts.
- Payment execution and automatic cancellation.
## Initial navigation
**Home · Transactions · Review · Settings**
Put reports within Home initially. The six-tab structure in the brief reflects the eventual product.
## First user journey
> Import/connect → see recorded spending → review a few uncertain items → understand the largest categories → return for next week’s update.
## Positioning hypothesis
> Understand your spending across supported accounts, with clear evidence and very little correction work.
Your TrustOps background may help shape permission explanations, evidence trails and clear uncertainty. Whether customers value these enough to switch or pay still needs testing.
