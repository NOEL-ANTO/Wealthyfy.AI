# Cash Management App — Notion Markdown Export

This archive contains the Cash Management App ideaboard and its eight subpages, read from Notion on 2026-10-11. Page order follows the index. Links between pages point to the corresponding local Markdown files.

The export preserves headings, lists, emphasis, links, callouts as blockquotes, and tables as GitHub-flavored Markdown. Notion-specific table-of-contents widgets were omitted; headings remain available to Markdown editors.
