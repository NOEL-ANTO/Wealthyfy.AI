# 🧪 04 · Competitors & Market Research Plan

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Preliminary competitor check
These are vendor-described capabilities, **not independently tested quality findings**. The separate competitor analysis was not included in this assessment.
| **Competitor** | **Verified positioning/capability** | **Investigate** |
| --- | --- | --- |
| axio | Android SMS-based tracking, budgeting, bills and reminders | Capture accuracy, correction burden, onboarding trust and experience alongside other financial products |
| Fold | Automatic bank-connected categorization through the Account Aggregator framework | Bank coverage, freshness, categorization quality and value after the first month |
| Rocket Money | Connected-transaction subscription detection and upcoming recurring bills | Recurring-detection quality, action flows and relevance to India |
| Easy Expense | Receipt scanning, email import, account connections, mileage and business reports | Whether personal users want this business-oriented feature set |
| Zoho Expense | OCR, reports, mileage and business expense workflows | Whether business features are drawing the roadmap toward a different buyer |
**AI-powered, automatic categorization and proactive reminders already appear in this market.**
## Positioning hypothesis
> Understand your spending across supported accounts, with clear evidence and very little correction work.
This must be tested against competitors through real tasks, rather than assumed to be distinctive.
## Move from complaints to behavior
A complaint about an existing app does not automatically establish a business opportunity. Determine whether the problem is frequent, whether people grant access and whether solving it changes behavior.
| **Step** | **Method** | **Output** |
| --- | --- | --- |
| Consolidate existing research | Record competitor, platform, version, date, evidence, complaint and affected user | Traceable comparison rather than a feature checklist |
| Interview 20–30 people | Include current users, abandoned-tracker users and non-users | Ranked problems and abandonment reasons |
| Test competitor journeys | Import, correct, reconcile, export, cancel and delete an account | Observed friction and limitations |
| Review recent app reviews | Sample positive/negative reviews on both platforms; separate old bugs from current issues | Recurring themes to investigate |
| Run a 4–6-week pilot | Consenting users receive summaries from supported imports | Evidence of usefulness, trust and ongoing effort |
| Test positioning | Compare spending clarity, less manual tracking and payments needing attention | Which promise attracts suitable users |
| Test willingness to pay | Concrete paid-beta offer with clear terms | Stronger evidence than hypothetical willingness |
## Interview prompts
- “Show me how you figured out last month’s spending.”
- “When did you last stop using an expense app?”
- “Which transactions did it get wrong?”
- “What access did you refuse?”
- “What did you do after seeing the report?”
- “What would make you uninstall immediately?”
> Use research consent for transaction samples. Do not casually collect statements in shared spreadsheets or chat groups.
## Initial segment hypothesis
**Salaried Indian adults using several payment methods who have tried and abandoned expense tracking.**
This is a proposed segment, not a confirmed market choice. Keep freelancers and families as separate research cohorts because their collaboration, reimbursement and accounting needs may differ.
## Market sizing
Do not multiply all Indian smartphone users by a subscription price. Start with the segment you can reach, supported banks/devices, observed activation, retention and paid conversion.
## Evidence to add from your competitor analysis
- [ ] Competitor names and tested platform/version.
- [ ] Specific complaint or limitation and supporting evidence.
- [ ] Frequency and affected user segment.
- [ ] Current workaround and switching willingness.
- [ ] Whether the gap is technically and commercially addressable.
## Sources
- [axio: Google Play listing](https://play.google.com/store/apps/details?hl=en-IN&id=com.daamitt.walnut.app)
- [Fold: Product website](https://www.fold.money/)
- [Rocket Money: Managing bills and subscriptions](https://help.rocketmoney.com/en/articles/2185531-managing-your-bills-and-subscriptions)
- [Easy Expense: Product website](https://www.easy-expense.com/login/)
- [Zoho Expense: India pricing and capabilities](https://www.zoho.com/in/expense/pricing/)
