# 🗓️ 06 · Delivery Roadmap & Founder Learning

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Planning assumptions
**6–8 months** for a focused production release with experienced support. **9–18 months or longer** if building while learning.
These are estimates, not delivery commitments. External approvals and bank integration can extend them.
The example below assumes one experienced mobile/full-stack engineer, part-time design and QA support, and you owning research and product decisions.
## Research-to-launch roadmap
| **Phase** | **Timing** | **Concrete work** | **Decision gate** |
| --- | --- | --- | --- |
| Research and founder preparation | Weeks 1–4 | Interviews, competitor testing, basic Git/mobile/backend learning and segment selection | Repeated problem supported by evidence |
| Capture feasibility | Weeks 3–6 | Native experiments, SMS policy assessment, statement parsers and bank-provider/legal discussions | Viable capture route for the promised experience |
| Prototype | Weeks 7–9 | Onboarding, permissions, reports, review inbox and incomplete-data states | Users understand results and corrections |
| Working alpha | Weeks 10–17 | Data model, capture/import, classification, offline entry, reports and export | Real data reconciles correctly |
| Production engineering | Weeks 18–23 | Sync, recovery, deletion, subscription handling if applicable, monitoring and security review | No unresolved release-blocking issues |
| Closed beta | Weeks 24–29 | Device testing and two monthly reporting cycles; measure trust and retention | Useful reports with acceptable correction effort |
| Store submission and limited launch | Weeks 30–32 | Disclosures, review access, billing tests, staged release and support readiness | Stable release and sustainable support workload |
## Learn alongside research
- Git and version control.
- How the mobile app, backend and database interact.
- Authentication versus authorization.
- API requests and background jobs.
- Data migrations, tests and deployment.
- Store releases and subscription lifecycles.
You do not need expertise in every area before starting. You need enough understanding to evaluate implementation decisions.
A clickable prototype or AI-generated codebase is useful progress. Production financial-data handling needs experienced review.
## First 30 days
- [ ] Consolidate competitor evidence.
- [ ] Interview 20–30 prospective users.
- [ ] Engage an experienced engineer for a short capture-feasibility exercise.
- [ ] Test one realistic spending-report prototype.
- [ ] Choose the initial segment.
- [ ] Record supported capture routes on Android and iOS.
- [ ] Agree a narrow MVP scope.
- [ ] Document reasons to proceed—or change direction.
> End the first month with a segment, supported capture route, narrow scope and an explicit investment decision. Do not fund the broader command centre before validating capture quality and correction effort.
