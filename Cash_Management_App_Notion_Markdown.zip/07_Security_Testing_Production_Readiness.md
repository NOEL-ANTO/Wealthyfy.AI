# 🛡️ 07 · Security, Testing & Production Readiness

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Define readiness through failures the app must survive
| **Area** | **Required evidence** |
| --- | --- |
| Financial correctness | Credit-card settlements, transfers, refunds, reversals and reimbursements reconcile |
| Import reliability | Re-importing the same file adds no duplicate expenses |
| Sync | Retries, concurrent edits, offline deletions, logout and account switching behave correctly |
| Recovery | A backup is restored successfully in a separate environment |
| Privacy | Logs, crash reports, analytics and support tools omit unnecessary financial content |
| Authorization | One account cannot read another account’s records or receipt links |
| OCR | Accuracy measured on labelled Indian receipts, including poor images |
| Notifications | Permission denial, restart, stale data and duplicated alerts are handled |
| Billing | Purchase, restoration, cancellation, expiry and refunds tested on each store |
| Releases | Database migrations and emergency disable/rollback processes exercised |
## Operational measures
Track:
- Crash-free use.
- Parsing failures.
- Stale connections.
- Duplicate rates.
- Correction rates.
- Restore failures.
Arrange an independent security review before broad distribution.
## Privacy and legal review
MeitY states that the DPDP Rules were notified in November 2025 with phased implementation.
Have Indian counsel map the provisions applicable at launch to actual data flows, consent, vendors, retention, deletion and incident response. Do not rely solely on a generic privacy-policy template.
## Store requirements
**Apple:** apps supporting account creation must let users initiate account deletion within the app.
**Google Play:** current requirements for applicable new personal developer accounts include at least 12 continuously opted-in closed testers for 14 days before applying for production access.
> Store testing minimums are administrative requirements, not sufficient evidence of product quality. Recheck platform policies before submission.
## Ownership
Own the repository, store accounts, cloud accounts, domain and vendor contracts yourself, including when an agency builds the app.
## Release checklist
- [ ] Capture route and permissions reviewed.
- [ ] Financial reconciliation cases pass.
- [ ] Import retry and sync conflict cases pass.
- [ ] Restore exercise completed.
- [ ] Independent security review addressed.
- [ ] Export and deletion verified.
- [ ] Store disclosures match actual data flows.
- [ ] Billing lifecycle tested if monetized.
- [ ] Support and incident-response ownership assigned.
- [ ] Limited rollout and emergency-disable process ready.
## Sources
- [MeitY: 2025–26 annual report, DPDP notification and phased timeline](https://www.meity.gov.in/static/uploads/2026/04/46face7d48c8f6a97030f713ad5fdab4.pdf)
- [Apple: Offering account deletion in your app](https://developer.apple.com/support/offering-account-deletion-in-your-app/)
- [Google Play: Testing requirements for new personal developer accounts](https://support.google.com/googleplay/android-developer/answer/14151465)
