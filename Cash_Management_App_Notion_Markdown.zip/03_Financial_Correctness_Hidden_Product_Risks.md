# 🔎 03 · Financial Correctness & Hidden Product Risks

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## A transaction is not necessarily an expense
Example: buy groceries for ₹2,000 on a credit card, then pay the card bill from a bank account. Importing both accounts must not report ₹4,000 of spending. The grocery expense is ₹2,000; the repayment settles the liability.
| **Event** | **Treatment to define** |
| --- | --- |
| Transfer between your own accounts | Transfer, excluded from spending |
| Credit-card repayment | Liability settlement, not a second purchase |
| ATM withdrawal | Movement into cash; later cash purchases are expenses |
| Refund | Linked adjustment to the original purchase |
| Failed or reversed UPI payment | Pending/reversed event, not completed spending |
| Shared purchase | Distinguish total paid from the user’s own share |
| Reimbursement received | Link to reimbursable spending |
| Loan EMI | Separate cash outflow reporting from principal/interest treatment where known |
You do not need a full accounting product. You do need consistent rules before building reports.
## Multiple sources can describe one purchase
A receipt, bank statement, SMS and email could refer to one payment. Preserve them as supporting evidence for one transaction, rather than four expenses.
Avoid merging legitimate purchases merely because merchant, date and amount match. Provide an undoable review process.
## Incomplete data can create misleading confidence
Show:
- Recorded spending.
- Connected accounts and imported periods.
- Last successful update.
- Items awaiting review.
- Known gaps such as cash and unconnected credit cards.
> “₹18,420 recorded across two accounts” is more defensible than “Your total spending is ₹18,420” when coverage is incomplete.
Do not display a coverage percentage without a credible denominator.
## Payment data does not establish subscription usage
No Netflix activity on a phone does not establish no usage on a TV, browser or shared account. Cloud storage can provide value without being opened regularly.
For early versions, ask:
> “You pay ₹649 monthly. Is this subscription still useful?”
Use **potential savings** until cancellation and subsequent billing outcomes are confirmed.
## Keep attention amounts separate
Bills owed, receivables and estimated savings should not be added into one headline metric.
| **Separate total** | **Meaning** |
| --- | --- |
| Upcoming payments | Money expected to leave the user’s accounts |
| Receivables | Money owed to the user |
| Potential savings | Estimated avoidable future charges, not money already saved |
## Verification can recreate manual work
The brief’s “AI suggests → user verifies → system saves” principle is useful for uncertain extraction. Requiring approval for every ordinary transaction could undermine the benefit.
Test a review inbox focused on ambiguity, unfamiliar merchants, duplicates and uncertain categorization. Track **correction effort**, not parsing accuracy alone.
## AI confidence needs evidence
Do not show “98% confidence” just because an LLM returned it. Validate extraction on labelled examples and calibrate any confidence indicator.
**\[Inference\]** Structured AI extraction can assist with unfamiliar inputs, but occasional unsupported fields are expected behavior, not guaranteed to be avoided. Use validation, source evidence and an “unknown” state.
## Define offline boundaries
Offline users can capture receipts and save expenses. Cloud OCR cannot finish without connectivity. Specify local extraction, queued work and pending-result states.
## Sync and backup are different
- **Sync:** keeps devices consistent.
- **Backup:** supports recovery from deletion, corruption or device loss.
Both require separate design and verification.
