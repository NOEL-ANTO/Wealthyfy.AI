# 📲 02 · Data Capture & Platform Feasibility

[Cash Management App Ideaboard](00_Cash_Management_App_Ideaboard.md)
> **\[Inference\] Planning assessment.** Recommendations, estimates and targets are hypotheses to validate. Verified platform and competitor facts are linked to their sources. This assessment is based on the supplied product PDF and preliminary research; the separate competitor analysis was not provided.

## Resolve capture before detailed UI design
Permissions do not provide equivalent access on Android and iOS.
| **Method** | **Practical implication** |
| --- | --- |
| Android transaction SMS | Google Play lists an exception for SMS-based money management, subject to review and approval. It is a possible route, not an automatic entitlement. |
| iPhone transaction SMS | Do not plan around general SMS-inbox access. Apple’s message-filter extension is limited to particular incoming messages and cannot write to a container shared with the main app. |
| Bank feeds in India | Account Aggregator access involves a regulated ecosystem. Buying an API subscription does not establish eligibility. |
| Gmail | Reading message bodies uses restricted scopes. Verification and, where restricted data is stored or transmitted through servers, a security assessment can affect cost and schedule. |
| User-imported statements | Useful cross-platform starting point; requires user action and bank-specific format support. |
| Receipts and manual entries | Necessary for cash and missing transactions; insufficient for the full automation promise. |
## Android SMS
Google’s money-management exception is subject to approval. Permission-derived data cannot be freely repurposed, and unrelated personal SMS must not be uploaded.
**Do not substitute notification scraping as a workaround for restricted permissions.**
## iOS boundaries
Apple documents app sandbox restrictions. Its message-filter extension works with specified incoming SMS/MMS from unknown senders, not a general historical inbox feed, and cannot write to shared containers with the containing app.
**\[Inference\]** Those constraints make a general iOS SMS expense-import feature an unsuitable assumption for this roadmap.
## Account Aggregator access
India’s Department of Financial Services describes an Account Aggregator Financial Information User as an entity registered with and regulated by a financial sector regulator.
**\[Inference\]** Establish a legally valid participation or partnership model rather than treating this as an ordinary developer API. Confirm provider coverage, commercial terms, freshness, and the permitted data flow for your specific product.
## Gmail integration
Google documents restricted scopes and assessment requirements. Treat the approval work as a product dependency, not a final integration detail.
## Investigate two routes
1. **Common Android/iOS foundation:** statement import, receipt capture, manual corrections and reliable reports.
2. **Continuous automation:** approved Android SMS capture and/or a legally viable bank-data arrangement.
> If intended iPhone customers require continuous automation, resolve the bank-data route before committing to that launch promise. A user-driven import experience must be described honestly.
## Feasibility deliverables
- Working native capture experiments on real devices.
- Supported sources and import formats.
- Permission and approval requirements.
- Bank-data legal/commercial assessment.
- Explicit fallback behavior when access is denied or unavailable.
- Decision on what each platform’s MVP can promise.
## Sources
- [Google Play: SMS and Call Log permissions](https://support.google.com/googleplay/android-developer/answer/10208820)
- [Google Play: Permissions and APIs accessing sensitive information](https://support.google.com/googleplay/android-developer/answer/16558241)
- [Apple: Security of runtime process](https://support.apple.com/en-in/guide/security/sec15bfe098e/web)
- [Apple: SMS and MMS message filtering](https://developer.apple.com/documentation/identitylookup/sms-and-mms-message-filtering)
- [Department of Financial Services: Account Aggregator framework](https://www.financialservices.gov.in/account-aggregator-framework)
- [Google: Gmail API scopes](https://developers.google.com/workspace/gmail/api/auth/scopes)
